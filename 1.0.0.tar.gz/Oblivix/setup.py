try:
    from os import system
    from sys import exit as Exit
except ImportError as e:
    print(e, "\nSomething went wrong importing the os and sys modules")

def ask():
    while True:
        answer2 = input("Run Oblivix? -> ").lower()
        if answer2 in ["yes", "ye", "y"]:
            system("python3 Oblivix.py")
            break
        elif answer2 in ["nah", "no", "n"]:
            Exit(0)
        else:
            print("Please answer yes or no.")
            Exit(1)

options = """
[1] pip install -r Requirements.txt
[2] pip3 install -r Requirements.txt
[3] python -m pip install -r Requirements.txt
[4] python3 -m pip install -r Requirements.txt
[5] pip install -r Requirements.txt --break-system-packages
[6] pip3 install -r Requirements.txt --break-system-packages
[7] python -m pip install -r Requirements.txt --break-system-packages
[8] python3 -m pip install -r Requirements.txt --break-system-packages
"""

print(options)
answer = input("Enter pip install type -> ")

try:
    if answer == "1":
        system("pip install -r Requirements.txt")
    elif answer == "2":
        system("pip3 install -r Requirements.txt")
    elif answer == "3":
        system("python -m pip install -r Requirements.txt")
    elif answer == "4":
        system("python3 -m pip install -r Requirements.txt")
    elif answer == "5":
        system("pip install -r Requirements.txt --break-system-packages")
    elif answer == "6":
        system("pip3 install -r Requirements.txt --break-system-packages")    
    elif answer == "7":
        system("python -m pip install -r Requirements.txt --break-system-packages")
    elif answer == "8":
        system("python3 -m pip install -r Requirements.txt --break-system-packages")
    else:
        print("Please enter a valid number")

    ask()

except KeyboardInterrupt as e:
    print("\nInterrupted by user.")
    Exit(0)
