try:
    from Programs.util import Colors, out, lerp, get_term_width, center, clear, info_box, shader, reset, check_for_update, rich_options, question, data_dir
    from sys import exit, executable
    from rich.console import Console
    from os import getenv, path
    from subprocess import run
    from pathlib import Path
    from time import sleep
    
    import os
except ImportError as e:
    print(e, "\n\nSomething went wrong importing modules.")
    exit(1)

logo_lines: list[str] = [
    " ▄██████▄  ▀█████████▄   ▄█        ▄█   ▄█    █▄   ▄█  ▀████     ████▀ ",
    "███    ███   ███    ███ ███       ███  ███    ███ ███    ███▌   ████",
    "███    ███   ███    ███ ███       ███▌ ███    ███ ███▌    ███  ▐███",
    "███    ███  ▄███▄▄▄██▀  ███       ███▌ ███    ███ ███▌    ▀███▄███▀",
    "███    ███ ▀▀███▀▀▀██▄  ███       ███▌ ███    ███ ███▌     ▄██▀██▄",
    "███    ███   ███    ██▄ ███       ███  ███    ███ ███     ███  ▀███",
    "███    ███   ███    ███ ███▌    ▄ ███  ███    ███ ███   ▄███     ███▄",
    " ▀██████▀  ▄█████████▀  █████▄▄██ █▀    ▀██████▀  █▀   ████       ███▄"
]

menu_1: str = """
[H] ┐ ┌──────────────────┐         ┌────────────────────────────────────────┐         ┌────────────────────────────────────────┐
    ├─┤   Wifi/Network   ├─────────┤                 OSINT                  ├─────────┤                                        ├─┐
[I] ┘ └┬─────────────────┘         └┬───────────────────────────────────────┘         └┬───────────────────────────────────────┘ └ [N]
       ├ [01] Packet Sniffer        ├ [09] Google Dorker                               ├ [21]
       ├ [02] ARP Sniffer           ├ [10] Username Checker                            ├ [22]
       ├ [03] Port Scanner          ├ [11] Database Lookup                             ├ [23]
       ├ [04] Deauther              ├ [12] IP Lookup                                   ├ [24]
       ├ [05] WiFi Jammer           ├ [13] Image Lookup                                ├ [25]
       ├ [06] Handshake Capture     ├ [14] Phone Lookup                                ├ [26]
       ├ [07] MITM intercept        ├ [15]                                             ├ [27]
       └ [08] Network mapper        ├ [16]                                             ├ [28]
                                    ├ [17]                                             ├ [29]
                                    ├ [18]                                             ├ [30]
                                    ├ [19] 
                                    └ [20] 
""" 

info = """
Creator:                    Nerux
Multi tool:                 Oblivix
Version:                    1.0.0 [Release] (not checked)
Next version:               1.1.0 [Better Output] (not checked)
Type:                       Python3
Released on (m/d/y):         
License:                    Custom

Tested on:
                            -- Kali Linux (AMD64)
                            -- MacOS (M2)
                            -- Asahi Fedora Linux 
Credits:
                            -- wock09092009 (Discord)
                            -- b.r1899 (Tiktok)
                            -- Scarlmao (Github)


Features:
                            -- Packet Sniffing
                            -- ARP Sweeping
                            -- WiFi Deauther
                            -- Port Scanning
                            -- Deauthentication
                            -- etc
                            
Features/help due to credits:
                            -- Database Lookup (wock09092009)
                            -- Operating system testing (b.r1899)
                            -- Phone Lookup (Scarlmao)
"""

help_text = """
To use Oblivix you can navigate through the menu using the following commands:
    - "<num>" num being to the program you wanna run (ex: 1 = packet sniffer)
    - 'n' to go to the next menu page.
    - 'b' to go back to the previous menu page.
    - 'i' to view information about Oblivix.
    - 'h' to view this help message.
    - 'u' to download/check for updates.
    - 'q' to quit the program.
    - "m <num>" to change to a specific page, num being the menu you want to change to 
"""

programs = {
    "1": "packet_sniffer.py",
    "2": "arp_sniff.py",
    "3": "port_scanner.py",
    "4": "deauther.py",
    "5": "wifi_jammer.py",
    "6": "handshake_capture.py",
    "7": "mitm_interceptor.py",
    "8": "network_mapper.py",
    
    "9": "google_dorker.py",
    "10": "username_checker.py",
    "11": "database_lookup.py",
    "12": "ip_lookup.py",
    "13": "image_lookup.py",
    "14": "phone_lookup.py"
}

menus = {
    1: shader(center(menu_1)) 
}

console = Console()
username = getenv("USER", "user")
here = path.dirname(path.abspath(__file__))
menu_number_file = Path(data_dir) / "menu_num.txt"

with open(Path(menu_number_file), 'r') as f:
    content = f.read().strip()

if content == "":
    with open(Path(menu_number_file), 'w') as f:
        f.write("1")
    menu_number = 1
else:
    menu_number = int(content)
    
LICENSE = Path(__file__).parent / "LICENSE"


def print_banner():
    start_rgb = (60, 25, 110)
    end_rgb   = (30, 10, 70)
    max_length = max(len(line) for line in logo_lines)
    term_width = get_term_width(default=max_length + 8)
    left_padding = (term_width - max_length) // 2
    pad_str = " " * left_padding
    steps = len(logo_lines)
    
    for i, line in enumerate(logo_lines):
        t = i / (steps - 1) if steps > 1 else 0.0
        r = lerp(start_rgb[0], end_rgb[0], t)
        g = lerp(start_rgb[1], end_rgb[1], t)
        b = lerp(start_rgb[2], end_rgb[2], t)
        color = f"\033[38;2;{int(r)};{int(g)};{int(b)}m"
        
        sleep(0.0625)
        print(color + pad_str + line + Colors.RESET)

    credits = "[ Made by Nerux ]"
    github  = "https://github.com/Nerrux"

    color_credits = f"\033[38;2;{start_rgb[0]};{start_rgb[1]};{start_rgb[2]}m"
    color_github  = f"\033[38;2;{end_rgb[0]};{end_rgb[1]};{end_rgb[2]}m"

    
    print(color_credits + credits.center(term_width) + Colors.RESET)
    print(color_github + github.center(term_width) + Colors.RESET)

    console.rule(style="#220B45")


def main():
    global menu_number
    
    with open(LICENSE, "r") as f:
        license_text = f.read().splitlines()
        for line in license_text:    
            print(f"{Colors.PURPLE}{center(line)}{Colors.RESET}")
        input(f"\n{Colors.PURPLE}Press{Colors.RESET} {Colors.WHITE}Enter{Colors.RESET} {Colors.PURPLE}to accept and continue -❯{Colors.RESET} ")

    
    while True:
        try:
            clear()
            print_banner()
            
            if menu_number in menus:
                print(menus[menu_number])
                
                
            choice = input(
                f""" {Colors.PURPLE}┌──({Colors.RESET}{Colors.WHITE}{username}{Colors.RESET}{Colors.PURPLE}@Oblivix)─[{Colors.RESET}{Colors.WHITE}Menu/{menu_number}{Colors.RESET}{Colors.PURPLE}]
 └─❯ """
            ).strip().lower()

            if choice == 'q':
                out("info", f"Exiting Oblivix")
                sleep(1)
                break

            elif choice == 'i':
                info_box(info)
                reset()
                
            elif choice == 'h':
                info_box(help_text)
                reset()
                
            
            elif choice == 'b':
                if menu_number == 1:
                    out("warning", "Invalid page number")
                    sleep(2) 
                else:
                    menu_number -= 1
                    
                    with open(menu_number_file, 'w') as f:
                        f.write(str(menu_number))

            elif choice == 'n':
                if menu_number == 5:
                    out("warning", "Menu 6 is under development")
                    sleep(2)
                else:
                    menu_number += 1
                    with open(menu_number_file, 'w') as f:
                        f.write(str(menu_number))
                    
            elif choice == 'u':
                options = [
                    "Check for new versions",
                    "download old versions",
                    "back"
                ]
                print()
                option = rich_options(options)
                
                if option == options[0]:
                    out("info", "Sending POST request to check server.. (this may take a while)")
                    response = check_for_update('u')
                
                
                    if response["outdated"]:
                        out("info", f"There is a new version ({response["latest_version"]} [{response["latest_version_name"]}])")
                        out("info", f"Your Oblivix version: {response["user_version"]} [{response["user_version_name"]}]")
                        update = question("Update?", "y/n")
                        
                        if update == 'y':
                            pass
                        elif update == 'n':
                            out("info", "Staying on current version")
                            sleep(2)
                        else:
                            out("warning", "Please only enter y or n")
                            
                    elif response["outdated"] == False:
                        out("info", f"Your version of Oblivix is up to date ({response["user_version"]} [{response["user_version_name"]}]")
                        sleep(2)
                        
                elif option == options[1]:
                    response = check_for_update('d')
                    
                        
                else:
                    sleep(0)
                    
            elif choice.startswith('m '):
                parts = choice.split()
                    
                if parts[1].isdigit(): 
                    target = parts[1]
                    target = int(target)
                    if target > 5:
                        out("warning", f"Unknown menu number {target}")
                        sleep(3)
                    else:
                        menu_number = target
                        
                        with open(menu_number_file, 'w') as f:
                            f.write(str(menu_number))
                else:
                    out("warning", "Please only enter digits")
                    sleep(2)

            elif choice in programs:
                name = programs[choice]
                file_path = os.path.join(here, "Programs", name)
                
                if os.path.exists(file_path):
                    try:
                        run([executable, file_path])
                        reset()
                    except KeyboardInterrupt as e:
                        print("\n\n")
                        out("error", "Interrupted")
                        reset()
                else:
                    out("error", f"Couldn't run {programs[choice]} cause it is not found")
                
            

            else:
                out("error", f"Invalid choice: {choice}")
                sleep(2)

        except KeyboardInterrupt:
            out("info", "\nInterrupted. Exiting")
            break

if __name__ == "__main__":
    main()