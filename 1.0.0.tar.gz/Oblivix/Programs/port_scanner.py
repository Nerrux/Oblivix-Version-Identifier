from socket import socket, AF_INET, SOCK_STREAM, inet_aton, error
from sys import exit
from threading import Thread
from queue import Queue
from util import out, question, lbl, shader, output_dir
from pathlib import Path

output = Path(output_dir) / "ports.txt"


logo = """                                                 
                                            +++=+===-======++                                       
                                   **++=====---:---::::.::-::-::-:--===                             
                              *++=====--------::-::-:....:.::.....::::::--==                        
                          *++====--==---:-:--=---=---::=-==:-.:....::.:::-------                    
                       *++=======+=+-===++++****#**#**=*++*=+--:--..:-:-+:-::.:::--=                
                     ++====--====*#*#******####%*##*#**%%#*####*+*#+#@%*=::.:.:.::::--=             
                   ++=====+=+=++****#**############***#*#**%##*%%%+**+#++*-=-:+=:::-=---==          
                ++++======+++*#*****##%%@@@@@%@@@@@%@@@@#*%%##%%##*%*#**+%%#####+=::*:::::=*        
               +++++**+++#*###%***%%%%@%%%##%%##########%%%%@@%%#**##*%*##*#*=**:#**++*-:::-=       
             +++=====+*+*#%#+*++*#%%##*#######*****#*#*###%##%%%##+===++***%%%@%%#*#---:-::::--     
           +++=====+*+#**++===+###%*%%#*+#***####%-=:*.+-=:#*##%%%*=-----=+*#*++*#***==+*::::-:-=   
          ++===+=+*++*#*=====+*##*#####**###%@@@@@#=-:%=+..+*###%%%*=:::::--=+****%#*%#+#*+:+-=::+  
        ======+++++#==+----==*#*#######*##@@@@@@@@---:::::==+*##%###*-::::::--=+***++#%#%#-+#++*-:*+
       +====++=++*#+=--=---=+##**#++*#*##@@@@@@@@@---:::::::=*#######=:...::::--==+**++**##***=:::  
      ======+=**+*=--------=***##*#####*@@@@@@@@@@@+::::-:::=##**#*+#+:....:::::--=++*++=+*#+--     
    -==-===+=*++*+=-------==*#########**@@@@@@@@@@@@*+==---=-+#*##**#*:.....::::::---=+=---=*#      
   -----===*+++====--------=*#######+*+#%@@@@@@@@@@@@@@@@%%#***+#**+**:.......:::::--==---:::       
  -:----=++++=====---------=+*##*#*+*+=*#@@@@@@@@@@@@@@@@##**=******#+:.......:.:::----::--         
  ::-===+++++===-----------=+**#**#*+*+*##@@@@@@@@@@@@@%##*+*+*#*+*##-:........::--:::::-           
  :-=*++++=++===-----------==+***+**+*+=***%@@@@@@@@@@%###*+***+**+#+:........::-:::::=:            
  :-:+=-=+++=====------:-----=+*+*+=****#+=+**##%%####*#*++++++**#*+-.......::::::::=               
  :--==-=========-------:::---=+*+++*+=*+++=++**++*+++=+=+=*+=**##=-.......:::::::-                 
  ::.::-.:+======-----::-:-----==*****+*+=**=*+**+*+**=*++#*+****=:.....:::::::+-                   
  --.::.-.=+=======----------:---=+**+*+=****##++***+**+*+***++=-:...::.::::-:                      
     ------==------::::--------:---=++++=*+***+**#*****+++==+=-.-::::::::-                          
                   ::::=:::::::::-----=+++++******#+++**#+.-:::::::-:.-                             
                                .::::::::::::::::-:-::::::::::.==.                                  
"""



def scan_port(ip, port, timeout=0.5):
    s = socket(AF_INET, SOCK_STREAM)
    s.settimeout(timeout)
    try:
        result = s.connect_ex((ip, port))
        if result == 0:
            return True
    except:
        pass
    finally:
        s.close()
    return False


def main():

    target = question("Enter IP to scan").strip()
    
    try:
        inet_aton(target)
    except error:
        out("error", "Invalid IP address.")
        exit()
        
    method = question("Enter scan method", "brute/most common").lower()
    
    if method == "most common":
        common_ports = [20, 21, 22, 23, 25, 53, 67, 68, 80, 110, 143, 443, 445, 3306, 3389, 5900, 8000, 8080]
        ports_to_scan = common_ports
    elif method == "brute":
        port_range = question("Enter range", "Ex: 6000 for 1-6000")
        
        try:
            port_range = int(port_range)
        except ValueError as e:
            out("error", "Please only enter a integer")
            
        ports_to_scan = range(1, int(port_range))
    else:
        out("error", "Invalid scan method.")
        exit()
    out("info", "Scanning...")

    open_ports = []
    port_queue = Queue()

    for port in ports_to_scan:
        port_queue.put(port)

    def worker():
        while not port_queue.empty():
            port = port_queue.get()
            if scan_port(target, port):
                open_ports.append(port)
                out("info", "Found open port: " + str(port))
            port_queue.task_done()

    num_threads = min(100, len(ports_to_scan))
    threads = []
    for _ in range(num_threads):
        t = Thread(target=worker)
        t.daemon = True
        t.start()
        threads.append(t)

    port_queue.join()

    if open_ports:
        sorted_ports = sorted(open_ports)
        ports_str = ", ".join(map(str, sorted_ports))

        with open(output, 'a') as f:
            f.write(f"{target} - {ports_str}\n")
        out("info", f"Open ports: {sorted_ports}")
    else:
        out("info", "No open ports found.")


if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    print("\n")
    main()
