from time import sleep
from os import path, makedirs
from scapy.all import sniff, wrpcap, conf
from sys import exit as Exit
from sys import executable, argv
from os import geteuid, execvp
from pathlib import Path

from util import out, question, shader, lbl, output_dir

logo = """                                                                                  
                    ...                                                          
                   ::::...       ::::                                                           
                   :::::::      ::::::                                                           
                   :::::::      ::::::                                                          
                   :::::::      ::::::                                                          
                   :::::::      ::::::                                                          
                   :::::::      ::::::                                                           
                   :::::::      ::::::                                                          
                   :::::::      ::::::                                                          
                   ::::::       ::::::                                                           
                    -::         --::                                                          
                    -:::        .--::                                                             
                    -:::        --::                                                            
                    -:::        --::                                       
                    -::         --::                                       
                -------------------------------------------:.                               
                ----------------------------------------=++++++:.                                
                -------------------------------------+++===++++++++.                             
                -----------------------------------+=+===::----=+++++.                             
                ----------------------------------+=++::--:--:::-:=+++.                             
                ---------------------------------+++=:--++++++++:::++++.                            
                --------------------------------++++::+++::::--++-:-+++:                      
                -------==-----===-----==-----==-+++=:-++::::::::++::+++-                        
                ------=====--=====---=====--====++++::::::::::::::::+++-                       
                --------------------------------=+++:::::::::::::::=+++                       
                ---------------------------------++++-::::::::::::=+++:                         
                .---------------------------------+++++-::::::::-+++++:                    
                ....................................=+++++++++++++=+++                   
                                                       +---==+:.+++=#**#                  
                                                                :*#*****+:                   
                                                                  #**#******               
                                                                   ##********            
                                                                    **********              
                                                                     -*********               
                                                                       +**#****              
                                                                          +***#
"""


class Packet_Sniffer:
    @staticmethod
    def main():
        if geteuid() != 0:
            out("warning", "Packet Sniffer requires root privileges!")
            sleep(1)
            execvp("sudo", ["sudo", executable] + argv)
            
        
    
        lbl(shader(logo), 0.0625)
        print("\n")
            
        iface = question(f"enter interface", "e.g. wlan0 or leave blank for default") or None
        bpf_filter = question(f"Enter BPF filter", "e.g. 'tcp port 80', leave blank for none") or None

        try:
            duration = int(question(f"Enter duration", "seconds, 0 for infinite") or 0)
        except ValueError:
            duration = 0

        try:
            count = int(question("Enter packet count", "0 for unlimited") or 0)
        except ValueError:
            count = 0

        save = question("Save packets to file?", "y/n")
        if save in ("y", "yes"):
            output = Path(output_dir) / "packets.pcap"

            makedirs(output_dir, exist_ok=True)

            if path.exists(output):
                if path.getsize(output) == 0:
                    pass
                else:
                    overwrite = question(f"File {output.name} already exists and is not empty, Overwrite?" "y/n")
                    if overwrite not in ("y", "yes"):
                        save_file = question("Enter a new filename")
                        if save_file:
                            if not str(save_file).endswith(".pcap"):
                                save_file = str(save_file) + ".pcap"
                            save_file = path.join(output_dir, str(save_file))
            else:
                
                open(output, "w").close()
        else:
            output = None

        promisc_answer = question(f"Enable promiscuous mode?", "y/n")
        promisc = promisc_answer and promisc_answer.strip().lower() in ("y", "yes")

        out("info", "Starting capture...")
        out("info", f"    Interface: {iface or '(default)'}")
        out("info", f"    Filter: {bpf_filter or '(none)'}")
        if duration > 0:
            out("info", f"    Duration: {duration}s")
        if count > 0:
            out("info", f"    Max Packets: {count}")
        if save_file:
            out("info", f"    Output: {save_file}")

        conf.verb = 0


        try:
            packets = sniff(
                iface=iface,
                filter=bpf_filter,
                promisc=promisc,
                store=True,
                timeout=duration if duration > 0 else None,
                count=count if count > 0 else 0,
            )
        except KeyboardInterrupt:
            out("warning", "Stopping capture early...")
            packets = []
        except Exception as e:
            out("error", f"Error while sniffing: {e}")
            return

        out("success", f"Capture finished. {len(packets)} packets captured.")
        if save_file and packets:
            try:
                wrpcap(save_file, packets)
                out("success", f"Packets saved to {save_file}")
            except Exception as e:
                out("error", f"Failed to save packets: {e}")

        out("info", "Done.")


if __name__ == "__main__": 
    Packet_Sniffer.main()
    Exit(0)
