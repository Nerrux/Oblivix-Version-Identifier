import requests
import concurrent.futures
from rich.console import Console
from rich.progress import Progress
from util import headers, question, out, shader, lbl, output_dir
from pathlib import Path
from random import choice

logo = """                                                           
                                 **********************                                             
                            ********************************                                        
                        ****************************************                                    
                     **********************************************                                 
                  ******************+:............-******************                               
                ***************.........................-***************                            
              *************.................................=*************                          
            ************.......................................+***********                         
           ***********............................................***********                       
         ***********............=######################:............**********                      
        **********...........:############################...........=*********                     
       *********=...........-###:::::-############:::::*###............**********                   
      *********.............###:::::::*##########:::::::###.............**********                  
     *********..............###:::::::::::::::::::::::::###..............+********                  
    *********...............###:::::::::::::::::::::::::###...............+********                 
    ********................###:::::::::::===-::::::::::###................*********                
   ********-................###:::::::::========::::::::###.................********                
   ********.................###::::::::=========::::::::###..................********               
  ********..................###::::::::=========::::::::###..................********               
  ********..................###:::::::::=======:::::::::###..................-********              
  ********..................###::::::::-+++++++=::::::::###...................********              
  *******=..................###::::::**************:::::###...................********              
 ********...................###:::::***************-::::###...................********              
 ********...................###:::::****************::::###...................********              
  *******-..................###:::::****************::::###...................********              
  ********..................###:::::****************::::###...................********              
  ********..................###:::::****************::::###..................:********              
  ********..................###:::::****************::::###..................********               
   ********.................###:::::::::::::::::::::::::###..................********               
   ********-................###:::::::::::::::::::::::::###.................********                
    ********................###:::::::::::::::::::::::::###................*********                
    *********...............###:::###########:::*####:::###...............=********                 
     *********..............###:::+++++++++++:::=++++:::###..............-********                  
      *********.............###:::::::::::::::::::::::::###.............+**********                 
       *********:...........=###:::::::::::::::::::::::+###............**************               
        **********...........=############################...........:*****************             
         **********+...........:#######################+............*******************             
           **********+............................................********************              
            ************.......................................-********************                
              *************.................................:**********************##               
                **************=..........................************************######             
                  ******************:..............+***************************##########           
                    *********************************************************#############          
                        ***************************************************#################        
                           *********************************   **********#####################      
                                 **********************         ******** #######################    
                                                                  ****     #######################  
                                                                             #####################  
                                                                               #################    
                                                                                 #############      
                                                                                  ##########        
                                                                                    #######         
                                                                                      ###                    
"""


console = Console()
SESSION = requests.Session()
output = Path(output_dir) / "usernames.txt"
lbl(shader(logo), 0.0625)
user = question("Enter username").strip()

PLATFORMS = {
    "Facebook": f"https://www.facebook.com/{user}",
    "Instagram": f"https://www.instagram.com/{user}",
    "Twitter": f"https://twitter.com/{user}",
    "TikTok": f"https://www.tiktok.com/@{user}",
    "Reddit": f"https://www.reddit.com/user/{user}",
    "Pinterest": f"https://www.pinterest.com/{user}",
    "Snapchat": f"https://www.snapchat.com/add/{user}",
    "Tumblr": f"https://{user}.tumblr.com",
    "Mastodon": f"https://mastodon.social/@{user}",
    "VK": f"https://vk.com/{user}",
    "OKru": f"https://ok.ru/{user}",
    "Meetup": f"https://www.meetup.com/members/{user}",
    "MySpace": f"https://myspace.com/{user}",
    "Gab": f"https://gab.com/{user}",
    "Parler": f"https://parler.com/{user}",
    "Nextdoor": f"https://nextdoor.com/profile/{user}",
    "Peertube": f"https://peertube.social/accounts/{user}",
    "TruthSocial": f"https://truthsocial.com/@{user}",
    "Bluesky": f"https://bsky.app/profile/{user}",
    "Threads": f"https://www.threads.net/@{user}",
    "GitHub": f"https://github.com/{user}",
    "GitLab": f"https://gitlab.com/{user}",
    "Bitbucket": f"https://bitbucket.org/{user}",
    "SourceForge": f"https://sourceforge.net/u/{user}",
    "StackOverflow": f"https://stackoverflow.com/users/{user}",
    "DevTo": f"https://dev.to/{user}",
    "CodePen": f"https://codepen.io/{user}",
    "Replit": f"https://replit.com/@{user}",
    "Kaggle": f"https://www.kaggle.com/{user}",
    "LeetCode": f"https://leetcode.com/{user}",
    "HackerRank": f"https://www.hackerrank.com/{user}",
    "TopCoder": f"https://www.topcoder.com/members/{user}",
    "Glitch": f"https://glitch.com/@{user}",
    "npm": f"https://www.npmjs.com/~{user}",
    "PyPI": f"https://pypi.org/user/{user}",
    "RubyGems": f"https://rubygems.org/profiles/{user}",
    "Packagist": f"https://packagist.org/users/{user}",
    "Launchpad": f"https://launchpad.net/~{user}",
    "OpenHub": f"https://www.openhub.net/accounts/{user}",
    "Atlassian": f"https://community.atlassian.com/t5/user/viewprofilepage/user-id/{user}",
    "Steam": f"https://steamcommunity.com/id/{user}",
    "Roblox": f"https://www.roblox.com/user.aspx?username={user}",
    "Minecraft": f"https://namemc.com/profile/{user}",
    "Twitch": f"https://www.twitch.tv/{user}",
    "EpicGames": f"https://store.epicgames.com/en-US/u/{user}",
    "Chess": f"https://www.chess.com/member/{user}",
    "Speedrun": f"https://www.speedrun.com/user/{user}",
    "Osu": f"https://osu.ppy.sh/users/{user}",
    "Lichess": f"https://lichess.org/@/{user}",
    "Faceit": f"https://www.faceit.com/en/players/{user}",
    "TrackerGG": f"https://tracker.gg/user/{user}",
    "PlanetMinecraft": f"https://www.planetminecraft.com/member/{user}",
    "ModDB": f"https://www.moddb.com/members/{user}",
    "NexusMods": f"https://www.nexusmods.com/users/{user}",
    "Guilded": f"https://www.guilded.gg/{user}",
    "SecondLife": f"https://my.secondlife.com/{user}",
    "Warframe": f"https://forums.warframe.com/profile/{user}",
    "RuneScape": f"https://apps.runescape.com/runemetrics/app/overview/player/{user}",
    "LeagueOfGraphs": f"https://www.leagueofgraphs.com/summoner/{user}",
    "OPGG": f"https://www.op.gg/summoners/{user}",
    "SoundCloud": f"https://soundcloud.com/{user}",
    "Bandcamp": f"https://bandcamp.com/{user}",
    "Spotify": f"https://open.spotify.com/user/{user}",
    "DeviantArt": f"https://www.deviantart.com/{user}",
    "Dribbble": f"https://dribbble.com/{user}",
    "Behance": f"https://www.behance.net/{user}",
    "Flickr": f"https://www.flickr.com/people/{user}",
    "Vimeo": f"https://vimeo.com/{user}",
    "YouTube": f"https://www.youtube.com/@{user}",
    "Dailymotion": f"https://www.dailymotion.com/{user}",
    "ArtStation": f"https://www.artstation.com/{user}",
    "Newgrounds": f"https://{user}.newgrounds.com",
    "Pixiv": f"https://www.pixiv.net/en/users/{user}",
    "Mixcloud": f"https://www.mixcloud.com/{user}",
    "AnchorFM": f"https://anchor.fm/{user}",
    "Letterboxd": f"https://letterboxd.com/{user}",
    "Trakt": f"https://trakt.tv/users/{user}",
    "Smule": f"https://www.smule.com/{user}",
    "VSCO": f"https://vsco.co/{user}",
    "500px": f"https://500px.com/{user}",
    "Medium": f"https://medium.com/@{user}",
    "Quora": f"https://www.quora.com/profile/{user}",
    "Disqus": f"https://disqus.com/by/{user}",
    "Patreon": f"https://www.patreon.com/{user}",
    "ProductHunt": f"https://www.producthunt.com/@{user}",
    "Keybase": f"https://keybase.io/{user}",
    "TripAdvisor": f"https://www.tripadvisor.com/Profile/{user}",
    "Goodreads": f"https://www.goodreads.com/{user}",
    "Wattpad": f"https://www.wattpad.com/user/{user}",
    "Instructables": f"https://www.instructables.com/member/{user}",
    "AllTrails": f"https://www.alltrails.com/members/{user}",
    "Strava": f"https://www.strava.com/athletes/{user}",
    "GaiaOnline": f"https://www.gaiaonline.com/profiles/{user}",
    "XDA": f"https://forum.xda-developers.com/m/{user}",
    "ArchLinux": f"https://bbs.archlinux.org/profile.php?id={user}",
    "LinuxQuestions": f"https://www.linuxquestions.org/questions/member/{user}",
    "Kongregate": f"https://www.kongregate.com/accounts/{user}",
    "Scratch": f"https://scratch.mit.edu/users/{user}",
    "IFTTT": f"https://ifttt.com/p/{user}",
    "Gravatar": f"https://en.gravatar.com/{user}",
    "Etsy": f"https://www.etsy.com/shop/{user}",
    "Fiverr": f"https://www.fiverr.com/{user}",
    "eBay": f"https://www.ebay.com/usr/{user}",
    "Amazon": f"https://www.amazon.com/s?i=merchant-items&me={user}",
    "EtsyPeople": f"https://www.etsy.com/people/{user}",
    "Gumroad": f"https://gumroad.com/{user}",
    "KoFi": f"https://ko-fi.com/{user}",
    "BuyMeACoffee": f"https://www.buymeacoffee.com/{user}",
    "OpenSea": f"https://opensea.io/{user}",
    "Redbubble": f"https://www.redbubble.com/people/{user}",
    "Society6": f"https://society6.com/{user}",
    "Depop": f"https://www.depop.com/{user}",
    "Poshmark": f"https://poshmark.com/closet/{user}",
    "StockX": f"https://stockx.com/user/{user}",
    "Grailed": f"https://www.grailed.com/{user}",
    "Reverb": f"https://reverb.com/shop/{user}",
    "Discogs": f"https://www.discogs.com/user/{user}",
    "ThemeForest": f"https://themeforest.net/user/{user}",
    "CreativeMarket": f"https://creativemarket.com/{user}",
    "Envato": f"https://envato.com/{user}",
    "TryHackMe": f"https://tryhackme.com/p/{user}",
    "HackTheBox": f"https://app.hackthebox.com/users/{user}",
    "HackerOne": f"https://hackerone.com/{user}",
    "BugCrowd": f"https://bugcrowd.com/{user}",
    "ExploitDB": f"https://www.exploit-db.com/?author={user}",
    "RootMe": f"https://www.root-me.org/{user}",
    "PacketStorm": f"https://packetstormsecurity.com/user/{user}",
    "ZoneH": f"http://www.zone-h.org/archive/notifier={user}",
    "SecurityTrails": f"https://securitytrails.com/list/apex_domain/{user}",
    "AbuseIPDB": f"https://www.abuseipdb.com/user/{user}",
    "TradingView": f"https://www.tradingview.com/u/{user}",
    "Coinbase": f"https://www.coinbase.com/{user}",
    "Binance": f"https://www.binance.com/en/user/{user}",
    "Gitcoin": f"https://gitcoin.co/{user}",
    "KeybaseBTC": f"https://keybase.io/{user}/bitcoin",
    "OpenBazaar": f"https://openbazaar.com/{user}",
    "Blockchair": f"https://blockchair.com/{user}",
    "Etherscan": f"https://etherscan.io/address/{user}",
    "Polygonscan": f"https://polygonscan.com/address/{user}",
    "BscScan": f"https://bscscan.com/address/{user}",
    "AboutMe": f"https://about.me/{user}",
    "AngelList": f"https://angel.co/u/{user}",
    "Crunchyroll": f"https://www.crunchyroll.com/user/{user}",
    "Duolingo": f"https://www.duolingo.com/profile/{user}",
    "CashApp": f"https://cash.app/${user}",
    "LastFM": f"https://www.last.fm/user/{user}",
    "Slack": f"https://{user}.slack.com",
    "Trello": f"https://trello.com/{user}",
    "Pastebin": f"https://pastebin.com/u/{user}",
    "Blogger": f"https://{user}.blogspot.com",
    "WordPress": f"https://{user}.wordpress.com",
    "Weebly": f"https://{user}.weebly.com",
    "Wix": f"https://{user}.wixsite.com/profile",
    "Trip": f"https://www.trip.com/members/{user}",
    "ResearchGate": f"https://www.researchgate.net/profile/{user}",
    "Academia": f"https://independent.academia.edu/{user}",
    "ORCID": f"https://orcid.org/{user}",
    "Coursera": f"https://www.coursera.org/user/{user}",
    "Udemy": f"https://www.udemy.com/user/{user}",
    "Codecademy": f"https://www.codecademy.com/profiles/{user}",
}


keywords = [
    "not found",
    "doesn't exist",
    "does not exist",
    "no results",
    "page missing",
    "user not found",
    "404",
    "503",
    "403",
    "unavailable",
    "this page isn’t available",
    "sorry, this page",
    "could not find",
    "profile does not exist",
    "account suspended",
    "no longer available",
]
output_lines = []

def fetch(url):
    try:
        r = SESSION.head(
            url,
            headers={"User-Agent": choice(headers)},
            timeout=10,
            allow_redirects=True
        )

        if r.status_code in [403, 405, 400, 406, 501]:
            r = SESSION.get(
                url,
                headers={"User-Agent": choice(headers)},
                timeout=10,
                allow_redirects=True
            )

        return r

    except requests.exceptions.RequestException as e:
        return str(e)


def is_valid(resp):
    if isinstance(resp, str):
        return False, f"ERROR: {resp}"

    if resp.status_code not in [200, 301, 302]:
        return False, f"HTTPS {resp.status_code}"

    text = ""
    try:
        text = resp.text.lower()
    except:
        pass

    for bad in keywords:
        if bad in text:
            return False, "Pattern matched"

    return True, "Exists"


def check(url):
    resp = fetch(url)
    ok, reason = is_valid(resp)
    return  ok, url, reason


def run_checker(username):
    with Progress() as progress:
        task = progress.add_task("Checking...", total=len(PLATFORMS))

        with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
            futures = [
                ex.submit(check, url)
                for url in PLATFORMS.values()
            ]

            for f in concurrent.futures.as_completed(futures):
                found, url, reason = f.result()
                out("success" if found else "warning", f"{url} | found: {found} | reason: {reason}")
                output_lines.append(f"{out("success" if found else "warning", f"{url} | found: {found} | reason: {reason}")}")
                progress.update(task, advance=1)

    

if __name__ == "__main__":
    run_checker(user)
    
    