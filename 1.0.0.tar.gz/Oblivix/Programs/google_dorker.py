from util import out, question, lbl, shader
from urllib.parse import quote_plus
from rich.console import Console
from rich.style import Style
from webbrowser import open
from rich.text import Text
from rich.live import Live

import readchar





logo = """                                                               
                                    .:@*++++++++#*..                                                     
                                .@++*+....      +@@+++=.                                                 
                            ..%*+...              ...@@++-.                                              
                        .++=.                       ..@*+%.                                            
            .*#++++*%. .%+-.    //                     ..@++.                                      
        ..++++++++++++@+#.    //                         -@+%.                                    
    ..++++*-..   ..@+@#.                                 ..@+*                                    
    .%+++%.       .@+%.                                   :..@+%.                     ++++.                
    .%+++-.       .@+*           .*#*#%-..          .**--=#-.@+=                     ++++.                
    .+++%.        .@+.       .:***********%.     .#----------%*+. ..%+++++++:+++..  ++++.   .%*****+%..  
    :+++:       .+@%++++++- .*****+....#****+.  .-----=....*--@+..*++++*%%++++++..  ++++. .#***+%%#***#. 
    :+++-       .+@+%+++++=.****=.      .****: .----..     ..-@+=%+++: .   .*+++.. ++++. ****.   .-***# 
    .+++*.       .%*%.++++..***%.        .***#.#---%       . #@+*+++#       .+++.  ++++..***..#******-. 
    .+++*.      .%**%++++.:***%         .****.%---*.     .=.=@+.+++*        +++.   ++++..*******%..     
    .++++#.    .%@+++++=..****..       %***+..----.     ...-%+.*+++.      *+++..   ++++..***#..    ..   
        .#+++++#*:.@%+@++#. ..****%.. ...****#.  +-----.   ----+@ .++++#...#+++++. ++++. .*****...#***% 
        ..#+++++++@@++%.    .#************:.    .-----------*+.  .-++++++++%+++.   *+++.  .+*********:. 
            .......%@+.       ..#******#.         .+=--=---*+.      ........+++.   ....     .......    
                ..=-@+-.                                 .++.           .*++#.                      
                .::++%...+#.                            .:      +#.    .%++++%                      
            .#++%:*+*..%@+@.                         :++.         %+++++++*                        
        ..++++++*#-+*=..@%@++..                   ..@++..            .....                            
    .:+++++++++*@..     .@%%%++@..            .-+++*.                                                
    *+++++++++++:..          .+%%%@++++++*++++++*@.                                                    
 *+++++++ .....                     ..:%@@@@@@*...                                                        
 *+++++++/////                                                                                            
*++++++++++:.                                                                                               
*+++++++ .
''''''                                                                                                   
"""

console = Console()

main_options = [
    "Search PDFs",
    "Search Images",
    "Search Videos",
    "Search Sites",
    "Custom Dork Query",
    "Cache Search (cache:)",
    "Related Sites (related:)",
    "Link Search (link:)",
    "Define Word (define:)",
    "Weather Info (weather:)",
    "Phonebook Lookup (phonebook:)",
    "Ext Search (ext:)",
    "Allinurl Search (allinurl:)",
    "Allintitle Search (allintitle:)",
    "Allintext Search (allintext:)",
    "Allinanchor Search (allinanchor:)",
    "Inanchor Search (inanchor:)",
    "Intext Search (intext:)",
    "Intitle Search (intitle:)",
    "Inurl Search (inurl:)",
    "Filetype Search (filetype:)",
    "Site Search (site:)",
    "Inpostauthor Search (inpostauthor:)",
    "Inposttitle Search (inposttitle:)",
    "Exit"
]

video_sites = [
    "YouTube",
    "X (Twitter)",
    "Vimeo",
    "Dailymotion",
    "Twitch",
    "Back"
]

selected_index = 0

def get_menu_text(options, selected_index):
    lines = []

    for i, option in enumerate(options):
        if i == selected_index:
            lines.append(
                Text(f"> {option}", style=Style(color="purple", bold=True))
            )
        else:
            lines.append(
                Text(f"  {option}", style=Style(color="purple4", dim=True))
            )

    return Text("\n").join(lines)


def select_from_menu(options):
    global selected_index
    selected_index = 0

    with Live(
        get_menu_text(options, selected_index),
        refresh_per_second=15,
        console=console,
        screen=False
    ) as live:

        while True:
            key = readchar.readkey()

            if key == readchar.key.UP:
                selected_index = (selected_index - 1) % len(options)
                live.update(get_menu_text(options, selected_index))

            elif key == readchar.key.DOWN:
                selected_index = (selected_index + 1) % len(options)
                live.update(get_menu_text(options, selected_index))

            elif key == readchar.key.ENTER:
                return options[selected_index]


def get_search_input(prompt: str, *, multiline=False) -> str:

    text = question(prompt)

    if not multiline:
        return text or ""

    print("(End input with empty line)")

    lines = []
    while True:
        line = input("> ")
        if not line.strip():
            break
        lines.append(line)

    return " ".join(lines)


def confirm(prompt: str) -> bool:
    """
    Original logic preserved but safe.
    """

    ans = question(f"{prompt}", "y/n")

    if not ans:
        return False

    if ans in ("y", "yes"):
        return True

    if ans in ("n", "no"):
        return False

    return False

def choose_operators_friendly(operators_map):
    selected_ops = []

    while True:
        out("info", "Pick a keyword type to add (or 0 to finish):")

        for num, (op, desc) in operators_map.items():
            out("info", f"{num}. {op} — {desc}")

        choice = question("> ")

        if choice == "0" or choice == "":
            break

        if not choice.isdigit() or int(choice) not in operators_map:
            out("warning", "Invalid choice, try again.")
            continue

        op = operators_map[int(choice)][0]

        val = get_search_input(f"Enter value for {op}:")

        if val:
            val = f'"{val}"'
            selected_ops.append((op, val))

    return selected_ops


def build_operator_part(op, val):
    val = val.strip()
    if not val:
        return ""
    else:
        val = f"'{val}'"
    return f"{op}{val}"


def build_query_with_operators(keyword, operators_map, extra_parts=None):
    selected_ops = choose_operators_friendly(operators_map)

    parts = extra_parts[:] if extra_parts else []

    for op, val in selected_ops:
        parts.append(build_operator_part(op, val))

    if keyword:
        parts.append(keyword)

    return " ".join(parts)


def build_query_pdf(keyword):
    operators_map = {
        1: ("intitle:", "words in page title"),
        2: ("inurl:", "words in URL"),
        3: ("intext:", "words in page text"),
    }

    return build_query_with_operators(
        keyword, operators_map, ["filetype:pdf"]
    )


def build_query_images(keyword):
    operators_map = {
        1: ("intitle:", "words in page title"),
        2: ("inurl:", "words in URL"),
        3: ("intext:", "words in page text"),
    }

    return build_query_with_operators(keyword, operators_map)


def build_query_sites(keyword):
    site = get_search_input(
        "Enter the site domain to search in (e.g. example.com):"
    )

    operators_map = {
        1: ("intitle:", "words in page title"),
        2: ("inurl:", "words in URL"),
        3: ("intext:", "words in page text"),
    }

    extra = [f"site:{site}"]

    return build_query_with_operators(keyword, operators_map, extra)


def build_query_custom():
    return get_search_input(
        "Enter your full custom Google dork query:",
        multiline=True
    )


def build_query_videos(keyword):
    site_choice = select_from_menu(video_sites)

    if site_choice == "Back":
        return None, None

    operators_map = {
        1: ("intitle:", "words in page title"),
        2: ("inurl:", "words in URL"),
        3: ("intext:", "words in page text"),
    }

    query = build_query_with_operators(keyword, operators_map)


    if site_choice == "YouTube":
        url = f"https://www.youtube.com/results?search_query={query}"

    elif site_choice == "X (Twitter)":
        url = f"https://twitter.com/search?q={query}"

    elif site_choice == "Vimeo":
        url = f"https://vimeo.com/search?q={query}"

    elif site_choice == "Dailymotion":
        url = f"https://www.dailymotion.com/search/{query}"

    elif site_choice == "Twitch":
        url = f"https://www.twitch.tv/search?term={query}"

    else:
        url = None

    return query if query else keyword, url


def build_simple_operator_query(keyword, operator, desc):
    out("info", f"Building query for operator: {operator} ({desc})")

    val = get_search_input(f"Enter value for {operator}:")
    val = f'"{val}"' # add quotes

    if not val:
        val = keyword
    

    return f"{operator}{val}"


def main():
    global selected_index

    while True:
        choice = select_from_menu(main_options)

        if choice == "Exit":
            break

        keyword = get_search_input(
            f"Enter main search indicator (words outside google dork):"
        )


        if choice == "Search PDFs":
            query = build_query_pdf(keyword)
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
            

        elif choice == "Search Images":
            query = build_query_images(keyword)
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice == "Search Sites":
            query = build_query_sites(keyword)
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice == "Search Videos":
            query, url = build_query_videos(keyword)

            if url is None:
                out("warning", "Cancelled video platform selection.")
                continue

        elif choice == "Custom Dork Query":
            query = build_query_custom()
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"


        elif choice.startswith("Cache Search"):
            query = build_simple_operator_query(keyword, "cache:", "Google cached pages")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Related Sites"):
            query = build_simple_operator_query(keyword, "related:", "Sites related to a domain")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Link Search"):
            query = build_simple_operator_query(keyword, "link:", "Pages linking to a URL")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Define Word"):
            query = build_simple_operator_query(keyword, "define:", "Definition of a word")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Weather Info"):
            query = build_simple_operator_query(keyword, "weather:", "Weather info for location")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Phonebook Lookup"):
            query = build_simple_operator_query(keyword, "phonebook:", "Lookup phone numbers")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Ext Search"):
            query = build_simple_operator_query(keyword, "ext:", "File extensions search")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Allinurl Search"):
            query = build_simple_operator_query(keyword, "allinurl:", "All words in URL")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Allintitle Search"):
            query = build_simple_operator_query(keyword, "allintitle:", "All words in title")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Allintext Search"):
            query = build_simple_operator_query(keyword, "allintext:", "All words in text")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Allinanchor Search"):
            query = build_simple_operator_query(keyword, "allinanchor:", "All words in anchor text")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Inanchor Search"):
            query = build_simple_operator_query(keyword, "inanchor:", "Words in anchor text")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Intext Search"):
            query = build_simple_operator_query(keyword, "intext:", "Words in page text")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Intitle Search"):
            query = build_simple_operator_query(keyword, "intitle:", "Words in page title")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Inurl Search"):
            query = build_simple_operator_query(keyword, "inurl:", "Words in URL")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Filetype Search"):
            ft = get_search_input("Enter filetype (e.g. pdf, docx, xls):")

            query = f"filetype:{ft}"
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"


        elif choice.startswith("Site Search"):
            query = build_query_sites(keyword)
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        elif choice.startswith("Inpostauthor Search"):
            query = build_simple_operator_query(keyword, "inpostauthor:", "Author of blog post")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"
        elif choice.startswith("Inposttitle Search"):
            query = build_simple_operator_query(keyword, "inposttitle:", "Title of blog post")
            url = f"https://www.google.com/search?q={quote_plus(query + ' ' + keyword)}"

        else:
            out("warning", "Unknown option, please try again.")
            continue

        if not url:
            out("warning", "No URL generated.")
            continue
        out("info", f"Generated Google Dork Query:\n{query}")
        out("info", f"Google Search URL: {url}")


        if confirm("Open this search in your default browser?"):
            out("info", "Launching web browser...")
            open(url)
        else:
            out("warning", "Cancelled opening browser.")


if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    print("\n")
    main()
