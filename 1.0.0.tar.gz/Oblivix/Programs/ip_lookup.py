from util import question, out, Colors, center, lbl, shader
from requests import get, Timeout
from json import JSONDecodeError
from sys import exit as Exit
from socket import gethostbyaddr, herror

logo = """                                                        
                                 ..###########%*######%*.                                           
                             -#######%#%#*-:..::=#%%########*                                       
                          %######+                      .#######*                                   
                       %#####:    .%#%:   #%  *#:   ##%#.    +%####+                                
                    -%###%    #####%.  .#%##  *##%%   *#####-   .%###+                              
                  =####:   %######:  :######  *######   #%###%#*   *#%+#                            
                .#%##   +########   ########  *#######%   ######%#.  =###%                          
               ####   %########.  *#########  *#########-  *#####+%#:  *##%*                        
             :###*  +.  .%##%#.  ###########  *###########  :%+#**   +.  ####                       
            *%##   #####*      -############  *##########%%  .   .######  =###.                     
           ###%  +%########%  .     .+#%####  *######=    ..   ##########  .*##:                    
          %#%#  %##########  =####%##*-            .=###=#+##  .#########%:  #*#.                   
         *##%  %#########*  .###############  *##%#####+######  +##########-  ###.                  
        .###  ####%####*%=  ################  *####%##%########  %##.                               
        ###  -######%*###  #################  *#####*########%#.       .=#%%%#=.                    
       +##%  #######%###:  #################  *#######*#####-    :################*%#.              
       ###  *#####%####%  ##################  *#%#######*#.   +#%######################*-           
      .##%  ##########%%  *#################  *#########:   %############################*#         
      *##+  ###########: .%#*###############  *#######%   ##################%#############%**       
      %##. **##########  :#################*  *#######   #####################################      
      %##  +***********  -***************+**  =+****+  .#######*#%    ###=        .-*##########     
      ###                                              ##########*    %*#.             .########    
      %%#. *###########  -##################  *####.  ############    %##.    ----:     .#######%   
      ###= :###########. .#########%#%######  *####  :############    ###.    ######%    +######%.  
      :*##  ###########*  ########*#########  *####  %##########%#    %%#.    #######    .######%+  
       ##*  ############  %#####*###########  *###+  %############    %##.    #######    -########  
       ###*  ###########.  ###*#############  *###*  %########*%%#    %##.    #####%.    ########*  
        ###  +##########%  #################  *###%  -######*#####    %##.              %########:  
       .+###  %##########.  ################  *##%#.  ############    %##.            ###########   
         ##%* .#########%#  =#%#############  *####%   ###########    %##.    ##########*#######    
          ###* .#%#####*##%  ############*+=  :=+*##*  =##########    %##.    ######%#*########.    
           ####  %##**####%#  %:       .=*##  *#*+-     #%########    %##.    #######%########-     
           .####  =###*##*     #############  *####*##.  %#######%    ###+   .#######*#%###%#:      
             ###=.  %#   :%##%  =###########  *##*#####   #############################*####.       
              .+#*%   #########   #%########  *#########   ################################         
                ###%#   #######%-  +########  *%#######     ############################%#          
                  #####   +#####%#   #######  *######-  :#.  +###########################           
                    ####%:   =####%#   #####  *###%-   ####-  :*+++++++++%#############:            
                      +###%#-    -###%   :##  *#% . .###%.      +#######+++###########              
                         *#####%=      .      .           *##+   +++++++##+*########%               
                            :#######*%*-.         .=#######%*+    ###%#++%++#######                 
                                 =#%#####################:        .-++#*+#*+#####%                  
                                         ..:---:.                    %#++#+####%.                   
                                                                      +*#=####%                     
                                                                       =#####.                      
                                                                         #%%                        
                                                                         .                          
 """

def _reverse_ip(IP):
    try:
        hostname = gethostbyaddr(IP)[0]
        return hostname
    except herror:
        return None


def locate_ip(IP):
    url = f'http://ip-api.com/json/{IP}'
    params = {'fields': '66846719'}
    try:
        response = get(url, params=params, timeout=5)
        data = response.json()

        if data.get('status') != 'success':
            out("error", f"{data.get("message", "Unknown error")}")
            return None, None

        print(center(f"\n{Colors.PURPLE}=== IP Information Lookup ==={Colors.PURPLE}"))
        out("info", f"Queried IP: {Colors.WHITE}{data.get('query', 'N/A')}{Colors.RESET}\n")

        fields = {
            "continent": "Continent",
            "country": "Country",
            "countryCode": "Country Code",
            "regionName": "Region",
            "city": "City",
            "district": "District",
            "zip": "Postal Code",
            "lat": "Latitude",
            "lon": "Longitude",
            "timezone": "Timezone",
            "offset": "UTC Offset",
            "currency": "Currency",
            "isp": "ISP",
            "org": "Organization",
            "as": "AS Number",
            "asname": "AS Name",
            "mobile": "Mobile Connection",
            "proxy": "Proxy / VPN",
            "hosting": "Hosting Server"
        }

        for key, label in fields.items():
            value = data.get(key)
            if value is True:
                value = f"{Colors.PURPLE}Yes{Colors.RESET}"
            elif value is False:
                value = f"{Colors.PURPLE}No{Colors.RESET}"
            elif value is None:
                value = f"{Colors.PURPLE}N/A{Colors.RESET}"

            if value:
                out("info", f"{label:<18}: {value}")
            else:
                out("warning", f"{label:<18}: {value}")
        out("info", f"Reverse lookup    : {_reverse_ip(IP)}")

        out("info", "Source            : ip-api.com")

        return data.get('lat'), data.get('lon')

    except Timeout:
        out("error", "Requests tomed out")
    except ConnectionError:
        out("error", "Network error. Are you connected to the internet?")
    except JSONDecodeError:
        out("error", "Invalid response received")
    except Exception as e:
        out("error", f"Unexpected error: {e}")

    return None, None

if __name__ == '__main__':
    lbl(shader(logo), 0.0625)
    IP = question(f"Enter IPv4 address", "x.x.x.x").strip()
    if not IP:
        out("warning", "No IP provided.")
        Exit(0)

    lat, lon = locate_ip(IP)
    if lat is not None and lon is not None:
        out("info", f"GM link:{Colors.WHITE} https://www.google.com/maps/place/{lat},{lon}{Colors.RESET}")

