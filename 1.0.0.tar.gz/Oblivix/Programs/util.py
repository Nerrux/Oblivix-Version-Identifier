from shutil import get_terminal_size
from datetime import datetime
from subprocess import run
from time import sleep
from os import getenv, path
from requests import get, post
from rich.live import Live
from rich.text import Text
from rich.style import Style
from rich.console import Console
from pathlib import Path

import readchar

symbols = {
    "info": "[-]",
    "success": "[✓]",
    "warning": "[!]",
    "error": "[#]"
}

headers = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.200 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.99 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.6668.71 Mobile Safari/537.36 EdgA/129.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:133.0) Gecko/20100101 Firefox/133.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 OPR/115.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Vivaldi/7.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.72 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
    "Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)",
    "Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.6668.81 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.103 Mobile Safari/537.36",
]

output_dir = path.join(path.dirname(__file__), "..", "Output")
data_dir = path.join(path.dirname(__file__), "..", "Data" )
input_dir = path.join(path.dirname(__file__), "..", "Input" )
console = Console()

class Colors:
    WHITE = "\033[1;37m"
    PURPLE = "\033[38;2;66;0;171m"
    RESET = "\033[0m"

def lerp(a: int, b: int, t: float) -> int:
    return int(a + (b - a) * t)

def get_term_width(default: int = 80) -> int:
    try:
        return get_terminal_size().columns
    except Exception:
        return default

def out(type:str, message:str):
    if type != "" and message != "":
        if type.lower() in symbols:
            now = datetime.now().strftime("%H:%M:%S")
            print(f"{Colors.PURPLE}{symbols[type]} [{now}] {message}{Colors.RESET}")
        else:
            out("error", "Please contact Nerux about this issue")
    else:
        out("error", "Please contact Nerux about this issue")
        
def question(message:str, clarify:str = ""):
    if message != "":
        if clarify != "":
            clarify = " [" + f"{clarify}" + "]"
        now = datetime.now().strftime('%H:%M:%S')
        return input(f"\033[38;2;66;0;171m[>] [{now}] {message}{clarify} -❯{Colors.RESET} ")
    else:
        out("error", "Please contact Nerux about this issue")
        return ""
        
def center(text) -> str:
    lines = text.splitlines()
    max_length = max(len(line) for line in lines) if lines else 0
    term_width = get_term_width(default=80)
    left_padding = (term_width - max_length) // 2 if term_width > max_length else 0
    centered_lines = [" " * left_padding + line for line in lines]
    return "\n".join(centered_lines)

def info_box(text: str) -> None:
    box_width = max(len(line) for line in text.splitlines()) + 4
    term_width = get_term_width(default=80)
    left_padding = (term_width - box_width) // 2 if term_width > box_width else 0
    pad_str = " " * left_padding

    print(pad_str + "┌" + "─" * (box_width - 2) + "┐")
    for line in text.splitlines():
        print(pad_str + "│ " + line.ljust(box_width - 4) + " │")
    print(pad_str + "└" + "─" * (box_width - 2) + "┘")

def clear():
    if getenv('OS') != 'Windows_NT':
        run(["clear"])
    else:
        run(["cls"])
        
def shader(text: str):
    start_color = (60, 25, 110)
    end_color   = (30, 10, 70)
    steps = 12

    colors = [
        (
            start_color[0] + (end_color[0] - start_color[0]) * i // (steps - 1),
            start_color[1] + (end_color[1] - start_color[1]) * i // (steps - 1),
            start_color[2] + (end_color[2] - start_color[2]) * i // (steps - 1),

        )
        for i in range(steps)
    ]

    colors += colors[-2::-1]

    def rgb(r, g, b):
        return f"\033[38;2;{r};{g};{b}m"

    result = []
    num_colors = len(colors)

    for i, line in enumerate(text.splitlines()):
        for j, ch in enumerate(line):
            r, g, b = colors[(i + j) % num_colors]
            result.append(f"{rgb(r,g,b)}{ch}\033[0m")
        result.append("\n")

    return "".join(result).rstrip("\n")

def _get_menu_text(options, selected_index):
    lines = []

    for i, option in enumerate(options):
        if i == selected_index:
            lines.append(
                Text(f"> {option}", style=Style(color="purple", bold=True))
            )
        else:
            lines.append(
                Text(f"  {option}", style=Style(color="purple4", dim=True))
            )

    return Text("\n").join(lines)

def rich_options(options):
    global selected_index
    selected_index = 0

    with Live(
        _get_menu_text(options, selected_index),
        refresh_per_second=15,
        console=console,
        screen=False
    ) as live:

        while True:
            key = readchar.readkey()

            if key == readchar.key.UP:
                selected_index = (selected_index - 1) % len(options)
                live.update(_get_menu_text(options, selected_index))

            elif key == readchar.key.DOWN:
                selected_index = (selected_index + 1) % len(options)
                live.update(_get_menu_text(options, selected_index))

            elif key == readchar.key.ENTER:
                return options[selected_index]
            

def lbl(text, delay):
    for line in text.splitlines():
        print(line)
        sleep(delay)
        
def reset():
    print("\n")
    question(f"Press {Colors.WHITE}enter{Colors.RESET}{Colors.PURPLE} to return to the menu")

def check_for_update(type):
    if type == 'u': # update
        url = "https://oblivix-version-identifier.onrender.com/c"
        data = {"hash": "KJQZGZ64c25uJd4uYEasHQoWZ2meotWL"}

        response = post(url, json=data)
        return response.json()
    
    elif type == 'd': # download
        url = "https://oblivix-version-identifier.onrender.com/chec/d"
        versions = get("https://pastebin.com/raw/XPAZg8R2").text.splitlines()
        
        out("info", "pick a version to download")
        option = rich_options(versions + ["back"])
        
        if option != "back":
            data = {"requested": option}
            version_content = get(url, json=data)
            
            with open(Path(output_dir) / "External" / f"Oblivix_{option}.tar.gz", "wb") as f:
                pass
            
            return {}
            
        else:
            return {}
        
    else:
        out("error", "Please contact Nerux about this issue")
        return {}