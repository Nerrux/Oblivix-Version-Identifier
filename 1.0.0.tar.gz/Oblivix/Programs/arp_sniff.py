try:
    import scapy.all as scapy

    from requests import get
    from netifaces import gateways, AF_INET
    from threading import Thread
    from util import out, question, shader, lbl, output_dir
    from pathlib import Path

    import time
    import os
except ImportError as e:
    print(e, "\n\nSomething went wrong importing modules.")
    exit(1)

logo = """                                           
                                                    #*====================*#                        
                                            %*=======----:::::::::::-------====*%                   
                                          %*========---:..         ..::::----===+#@                 
                                     ##+===-:.         ...............  ..::--==+#%%%               
                                   %#+===-:..         .................   ..::-==+**#%@             
               %#***#%@       %#+===--:.   ....-::............................:--==+*#%% @          
               ***####%@@    #+=---:........:::--::::..........................::-=+#%%@@           
               %#####%%@@@##*=-:.   .:---.::---:::...:::.........................::-*%@@@@@@@       
                @%%%%@@@@#+=-:.....-----:---::::..:::...:..........................:+##@@@@ @       
                  @@@@@%*=-:::...:----------::.................................... .==+#@@@@@       
                    %#*+-*##++*******************************-:...................  -==#@@@@@       
                   %#+=-:*@@@##******************************+-...................  -==#@@@@@       
                  #+=-:::%%@@@@*+++++++++++++++++++++++++++++=-...:...........:::.  -==#@@@@@       
                #*=-:..:-@@@%###*++++====+=+===+=+===+=+======-...................  -==#@@@@@       
               *==-.. -=#@@@#++*%@#+=--:-==-::-==--::-==-::-==-:::................  -==#@@@@@       
               ===-  .-*%@@@++++*#@%#+==-:::===:::===:::-==:::---::............:..  -==#@@@@@       
             %#+--..:-*#%@@@++++++*%@%*==-::===:::===:::-==:::-==-:::.........:::.  -==#@@@@@       
            %+=-...-+****@@@+++===++*%@%*===:::===:::===:::-==-:::=-:::.......:::. .-==#@@@@@       
            ===-  .-+*+*#@@@+++++==+++#%@#*=--:---:::---:::----:::--:::::...::::...:-==#@@@@@       
           %+=-. .:=++*##@@@++++++===+++#%@#+==-::===:::-==:::-==-:::::::..:::.. :--===#@@@@@       
         %#+-:..:-+++*+*#@@@+++++==++==++*#@@#+==-:::---:::----:::--:::::..:::.  -=====#@@@@@       
         +==-. .-++***+**@@@%++====++====++*#@%*+=-::===:::-==-:::=-::::.::::...:-====*%@@@@@       
         ===:  .=+*+++*#%@@@%#++++====++===++*%@%*===:::-==:::-==-::::::::::..:--===+*#@@@@@@       
         ===:  .=+*+++**%@@@%*++++====++====+++*%@%*=--:-==::--==-:::::::::..:-=====*%%@@@@ @       
         ===:  .-++***++*%@%#++====++====+++===++#%%#===-::-=====-::::::...:--===+=+%@@@@@@@        
         ===:  .-+++++++++**+++++===============++***+===--====-::::::::.::---===++#@@@@@@          
         ===:  :=**+++***+++***++++===++====+++===++++++======-::::-:...:---=====*%%@@@@@@          
         ===:. .-=+***+++***+++**++++====+++===+++==+++++++++=-:::...::---======*%%@@@@@@           
         %*=-:..:-=****++***+++***++++==++++==+++++==++++++++=-:::..:---=======+*%@@@@@@ @          
           #+--:.::+*****+++***++++**++++++++++++++++++==--::::..:-:---======++*%@@@@@              
            ===-:..:=+***+++***++++**++++***+++***++**+=-::::...:----=======+**#%@@@@ @             
            *==---. .:-=+***+++***++++***+++***++=++=-::..   .:-==========+**#%@@@@@@@@             
             #*=---   .:=+++***++++**++++***+++=-:::......:---==========+**#%@@@@@@                 
               #+=-..   .---====--====--====--::::.   .:-=============++*#%@@@@ @  @                
               %%*+=---:..                       .::-===============++*#%@@@@@@@                    
               @%#*+=----:..                   ..:-===============+*#%%%@@@@@@                      
                 @%#****+=-==================================++*%%%@@@@@@@ @@                       
                   @%*#%@%%**+++========================+++*#%%@%@@@@@@@@@                          
                       @@@@@@@%##=====================++*%%%@@@@@@@@@@@@ @                          
                       @@ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                 
                       @ @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ @                                
                              @ @@@@@@@@@@@@@@@@@@@@@=+=#%%@@@@@@                                   
                                               #@@@%%.  =+*#%@@@@                                   
                                          %#+====+***...=+++*******#%@@@@@@@@                       
                                     %%*====-------:...:====+********#%@@@@@@                       
                                    @*====----:::-..::::======+********#%@@@@ @@                    
                                  %%%+---:.       ::::::==========+******#%@@@@ @                   
                                  %%#*+-:..       .:::::==========+*****#%%@@@@ @                   
                                    %#*****=:::.      .:+=====+*****#%@@@@@@@ @@                    
                                     @@#*#@@%*===-----=*%%#*#%%@%#%@@@@@@@@@@                       
                                         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                       
                                          @@@@@@@@@@@@@@@@@@@@@@@@@@ @@                             
                                         @  @ @@@@@@@@@@@@@@@@@@@@@@@ @                             
"""
SPACE = " " * 5
seen = {}
LAST_FOUND = time.time()
output = Path(output_dir) / "arp_sniffed.txt"

def get_gateway():
    try:
        return gateways()['default'][AF_INET][0]
    except:
        return None

def get_vendor(mac):
    try:
        r = get(f"https://api.macvendors.com/{mac}", timeout=2)
        if r.status_code == 200:
            return r.text.strip()
    except:
        pass
    return None

def guess_device(vendor):
    if not vendor:
        return None

    v = vendor.lower()

    if any(x in v for x in ["apple", "iphone", "ipad", "mac"]):
        return "Apple Device"

    if any(x in v for x in ["samsung", "xiaomi", "huawei"]):
        return "Android Device"

    if any(x in v for x in ["tp-link", "asus", "arris", "nokia", "router"]):
        return "Router"

    if any(x in v for x in ["intel", "dell", "lenovo"]):
        return "Computer"

    return "Unknown"

def show(ip, mac, vendor, dev):
    ip = ip or "None"
    mac = mac or "None"
    vendor = vendor or "None"
    dev = dev or "None"

    with open(os.path.join(output), "a") as f:
        f.write(f"{ip}{SPACE}{mac}{SPACE}{vendor}{SPACE}{dev}\n")
    out("info", f"{ip}{SPACE}{mac}{SPACE}{vendor}{SPACE}{dev}")

def register(ip, mac):
    global LAST_FOUND

    if ip in seen:
        return

    vendor = get_vendor(mac)
    dev = guess_device(vendor)

    seen[ip] = True
    LAST_FOUND = time.time()

    show(ip, mac, vendor, dev)

def arp_sweep(network):
    arp = scapy.ARP(pdst=network) # type: ignore
    ether = scapy.Ether(dst="ff:ff:ff:ff:ff:ff") # type: ignore
    packet = ether/arp

    ans = scapy.srp(packet, timeout=2, verbose=False)[0]

    for _, r in ans:
        register(r.psrc, r.hwsrc)

def arp_sniff(pkt):
    if pkt.haslayer(scapy.ARP): # type: ignore
        register(pkt.psrc, pkt.hwsrc)

def killer():
    while True:
        if time.time() - LAST_FOUND > 15:
            out("info", "ARP Sweep finished.")
            os._exit(0)
        time.sleep(1)



if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    print("\n")
    
    gateway = get_gateway()

    if os.path.exists(output) and os.path.getsize(output) > 0:
        choice = question(f"Output file 'arp_sweep.txt' already exists and is not empty. Overwrite?", "y/n")
        if choice.strip().lower() in ("y", "yes"):
            with open(output, "r+") as f:
                f.truncate(0)
            out("warning", "arp_sweep.txt cleared")
        else:
            out("info", "Appending to existing arp_sweep.txt")

    if not gateway:
        out("error", "No gateway found, are you connected to the internet?")
        exit()
    
    network = ".".join(gateway.split(".")[:3]) + ".0/24"
    show(gateway, None, None, "Router")
    Thread(target=killer, daemon=True).start()
    arp_sweep(network)
    scapy.sniff(prn=arp_sniff, store=0)