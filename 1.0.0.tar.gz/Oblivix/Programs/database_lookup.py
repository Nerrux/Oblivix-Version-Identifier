from util import shader, out, question, clear, Colors, lbl, output_dir
from datetime import datetime
from sys import exit as Exit
from requests import post
from pathlib import Path
from time import sleep

logo = """                                                                
                      #########################################                                     
               ########################################################                             
          #######################                    #######################                        
       #############                                              ############                      
      ########                                                          ########                    
     ######                                                                ######                   
     #####                                                                  #####                   
     ########                                                            ########                   
     #############                                                  #############                   
     ######################                                ######################                   
     #####   ############################################################   #####                   
     #####         ###############################################          #####                   
     #####                      ######################                      #####                   
     #####                                                                  #####                   
     #####                                                                  #####                   
     #####                                            ########              #####                   
     #####                                      ####################        #####                   
     #####                                   ##########################      ###                    
     #####                                ##########            ##########    #                     
     #######                            ########                    ########  .                     
     ##########                        ######                          ######                       
     ##################              ######                              ######                     
     ##### ####################     ######                                ######                    
     #####       ##############    ######                                  ######                   
     #####                ####     #####                                    #####                   
     #####                        #####                                      #####                  
     #####                        #####                                      #####                  
     #####                       #####                                        #####                 
     #####                       #####                                        #####                 
     #####                       #####                                        #####                 
     #####                       #####                                        #####                 
     ######                       #####                                      #####                  
     ##########                   #####                                      #####                  
     ###############               #####                                    #####                   
     ##### ####################     #####                                  ######                   
     #####     ##################   ######                                ######                    
     #####            ###########     ######                            ##########                  
     #####                             #######                        ####### ######                
     #####                               ########                  ########     ######              
     #####                                 ###########        ###########         ######            
     #####                                   #############################          #####           
     #####                                       ##################    ######          #####         
      ######                                                             ######          ######       
       #######                                                              ######         ######     
         #########                                                     ######  ######         ####     
           ############                                             ########      ######       ####     
              ###################                      ###################          #####    #####      
                  ##################################################                  ###########       
                         #####################################                          ########         
"""

SNUSBASE_KEY = "sbmeovhou6ecsn9fd9wcwnwwvsvwnc"
SNUSBASE_URL = "https://api.snusbase.com/data/search"
output = Path(output_dir) / "database_lookup_output.txt"


def snusbase_lookup():
    query = question(f"type what to search", "username, password, email, hash, IP or domain").strip()
    
    if query.lower() == "":
            out("warning", "invalid query search")
            Exit()
            


    wildcard_input = question("Do you want wildcard search enabled?", "y/n").lower()
            
    if wildcard_input == 'y':
            wildcard = True
    elif wildcard_input == 'n':
            wildcard = False
    else:
        out("warning", "Defaulting to no wildcard")
        wildcard = False

    headers = {
        "Auth": SNUSBASE_KEY,
        "Content-Type": "application/json"
    }

    payload = {
        "terms": [query],
        "types": [
        "email",
        "username",
        "password",
        "hash",
        "name",
        "lastip",
        "_domain"
        ],
            "wildcard": wildcard
        }

    out("info", "Searching...")

    r = post(SNUSBASE_URL, headers=headers, json=payload, timeout=15)
            
          
    if r.status_code == 429:
        out("error", "Your IP rate limit has been reached, try waiting a few hours or days")
        sleep(3)
        Exit()

    data = r.json()

    clear()

    if not data.get("results"):
        out("warning", f"No results have been found for {query}")
        sleep(3)

    output_lines = []
    output_lines.append(f"Snusbase Search: {query}")
    output_lines.append(f"Wildcard: {"ON" if wildcard else "OFF"}")
    output_lines.append(f"Time: {datetime.now()}")
    output_lines.append("=" * 70)

    out("info", "Results:")

    for table, rows in data["results"].items():
        print(f"{Colors.PURPLE}Database:{Colors.PURPLE}{table}")
        print(f"{Colors.PURPLE}{'-'*70}{Colors.PURPLE}")
        output_lines.append(f"\nDatabase: {table}")
        output_lines.append("-" * 70)

        for row in rows:
            for k, v in row.items():
                print(f"{Colors.PURPLE}{k:<12}: {v}")
                output_lines.append(f"{k}: {v}")
            print(f"{Colors.PURPLE}{'-'*70}{Colors.PURPLE}")
            output_lines.append("-" * 70)

    save = question("Do you want to save results?", "y/n").lower()
    if save == 'y':
        with open(output, "w", encoding="utf-8") as f:
            for line in output_lines:
                f.write(line + "\n")


            
    elif save == 'n':
        out("info", "Results not saved")
        Exit()
            
            
if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    print("\n")
    snusbase_lookup()