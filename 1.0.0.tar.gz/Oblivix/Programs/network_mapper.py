try:
    import networkx as nx
    import matplotlib.pyplot as plt
    from util import out, shader, lbl, output_dir
    from pathlib import Path
    import scapy.all as scapy
    from threading import Thread

    import os
    import time
except ImportError as e:
    print(e, "\n\nSomething went wrong importing modules.")
    exit(1)
logo = """


                                     _--_                                                               
                                  #@      @.                         .@@@@*._                         
             ____               .+          @                     %=          @                      
          %@.    #@.            %            @                   %              @                    
        @            @         :             @                  @                @                   
      @               *     /.*@@%            @@@@@@@@@@@@@@@@@                  @                   
     @                 % .-      .=          @                  =                @                   
     @                  @         %%      @.                    #               @                    
     #                  @            -  -                          @          @                     
     @                  *             %                             @@#  -@@.                       
     .-                @             @                             @                                
       @              @             @                            *.                                 
        -@          @              @                            @                                   
            %@@@@=                @                           .#                                    
                                 #                   =@@@#@@@@                                      
                                :.                @             @                                   
                                -               @                 @                                 
                            :#*%               @                   *                                
                        .@        @           @                     @                               
                       @            @         .                      .                              
                      @              +                               :                              
                      @              @        @                     @ @@                              
                      @              @         =                   .:  @@          :@@=  -@@-       
                       #            @           @                 %.    @@      .@            @-    
                        @.        +*          @.   :@           @+       @@    @                @   
                           @@@@@=          #@.        :@@.  @@-           @   %                  -  
                                       @@                                   @@                    @ 
                *@@@@@            +@:                                        *                    . 
             :%        .@     @@                                             *                    . 
            @            @@=                                                 @                    @ 
            #            .:                                                   @                  %  
            @            .                                                     @                @   
            :.           @                                                       @.           @     
              @        @                                                            %@@@@@@@        
                -....-
"""


SPACE = " " * 5
seen = {}
LAST_FOUND = time.time()
output = Path(output_dir) / "arp_sniffed.txt"

def parse_arp_sniff(file_path):
    devices = {}
    if not os.path.exists(file_path):
        out("error", f"ARP sweep file not found: {file_path}")
        return []
    with open(file_path, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 4:
                ip, mac, vendor, dev = parts[:4]
                if ip not in devices or (devices[ip]['dev'] == 'None' and dev != 'None'):
                    devices[ip] = {
                        "ip": ip,
                        "mac": mac,
                        "vendor": vendor,
                        "dev": dev
                    }
    return list(devices.values())


def visualize_network(devices):
    G = nx.Graph()
    # Add nodes with device type
    for device in devices:
        label = f"{device['ip']}\n{device['dev']}"
        G.add_node(label, type=device['dev'])
    # Find all routers
    routers = [d for d in devices if d['dev'].lower() == 'router']
    # Connect devices to nearest router (by IP subnet)
    for device in devices:
        if device['dev'].lower() == 'router':
            continue
        # Find router in same subnet
        subnet = '.'.join(device['ip'].split('.')[:3])
        router = next((r for r in routers if r['ip'].startswith(subnet)), None)
        if not router and routers:
            router = routers[0]
        if router:
            router_label = f"{router['ip']}\n{router['dev']}"
            label = f"{device['ip']}\n{device['dev']}"
            G.add_edge(router_label, label)
    # Color nodes by device type
    color_map = []
    for node in G.nodes(data=True):
        dev_type = node[1].get('type', '').lower()
        if dev_type == 'router':
            color_map.append('red')
        elif 'android' in dev_type:
            color_map.append('green')
        elif 'unknown' in dev_type:
            color_map.append('gray')
        elif dev_type == 'none':
            color_map.append('lightgray')
        else:
            color_map.append('skyblue')
    plt.figure(figsize=(12, 8), facecolor='black')
    pos = nx.spring_layout(G, seed=42)
    nx.draw(G, pos, with_labels=True, node_color=color_map, edge_color='gray', node_size=2200, font_size=10)
    plt.title("Network Map", color='black')
    plt.show()


def get_gateway():
    try:
        import netifaces
        return netifaces.gateways()['default'][netifaces.AF_INET][0]
    except:
        return None

def show(ip, mac, vendor, dev):
    ip = ip or "None"
    mac = mac or "None"
    vendor = vendor or "None"
    dev = dev or "None"

def register(ip, mac):
    global LAST_FOUND
    if ip in seen:
        return
    seen[ip] = True
    LAST_FOUND = time.time()
    show(ip, mac, None, None)

def arp_sweep(network):
    arp = scapy.ARP(pdst=network) # type: ignore
    ether = scapy.Ether(dst="ff:ff:ff:ff:ff:ff") # type: ignore
    packet = ether/arp
    ans = scapy.srp(packet, timeout=2, verbose=False)[0]
    for _, r in ans:
        register(r.psrc, r.hwsrc)

def arp_sniff(pkt):
    if pkt.haslayer(scapy.ARP): # type: ignore
        register(pkt.psrc, pkt.hwsrc)

def killer():
    while True:
        if time.time() - LAST_FOUND > 20:
            break
        time.sleep(1)

def scan_network():
    gateway = get_gateway()
    if not gateway:
        out("error", "No gateway found, are you connected to the internet?")
        return False
    network = ".".join(gateway.split(".")[:3]) + ".0/24"
    show(gateway, None, None, "Router")
    Thread(target=killer, daemon=True).start()
    arp_sweep(network)
    scapy.sniff(prn=arp_sniff, store=0, timeout=10)
    return True

def extract_devices():
    devices = {}
    if not output.exists():
        out("error", f"arp_sniffed.txt file not found")
        return []
    with open(output, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 4:
                ip, mac, vendor, dev = parts[:4]
                if ip not in devices:
                    devices[ip] = {
                        "ip": ip,
                        "mac": mac,
                        "vendor": vendor,
                        "dev": dev
                    }
    return list(devices.values())


def main():
    out("info", "It's reccomended to run Arp Sniffer before running Network Mapper")
    out("info", "Scanning network for devices")
    scan_network()
    out("info", "Parsing ARP sweep results")
    devices = extract_devices()
    if not devices:
        out("error", "No devices found to visualize.")
        return
    out("info", f"Visualizing {len(devices)} devices...")
    visualize_network(devices)


if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    main()
