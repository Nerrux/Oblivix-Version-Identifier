from util import out, question, shader, lbl, output_dir, rich_options, input_dir
from requests import get
from pathlib import Path
from os import listdir
from sys import exit

logo = """                                                                    
                  .........=+++++=.                              .-+++++=                   
                  ....+++++++++++=                                -+++++++++++                  
               ....++++++++++++++=                                -++++++++++++++               
             . ..++++++++++++++++=                                -++++++++++++++++             
            ...++++++++++++++=:....                              ....:=++++++++++++++            
         ....:++++++++++=..                                              ..=++++++++++:         
         ...-+++++++++....                                                 ...+++++++++=         
         ..-++++++++:.            ......:============......                   .:++++++++-         
         ..++++++++...            ..======================..                  ...++++++++         
         .++++++++....      .....============================.....            ....++++++++         
         .++++++++...    .....-================================:.....          ...=+++++++         
         .+++++++..      ...:====================================....            ..+++++++         
         -+++++++..      ..=============...        ...=============..            ..+++++++=         
         .:::::::..      .===========.......         ....===========.            ..:::::::         
                      ...==========...                  ...==========. .                            
                      ..=========.....   .  ..          .....=========..                            
                      .=========...     .......            ...=========.                            
                      .========....     ..----.... ..      ...:========.                            
                      =========..       ..----...-...         .=========                            
                      ========.      ..........-----....      .:========..                          
                      ========.      ....-....-------...      ..========...                         
                      ========.      ..-----.:--------:.      ..========..                          
                      ========:.. ....-------..---------...   .-========...                         
                      =========.. ...---------..:--------..   .========-                            
                      .========-...:-----------:..---------...=========.                            
                      .=========:............................-========-.                            
                      ..==========...                   ....==========..                            
                      ...==========...                  ..:==========...                            
                         .===========-...            ...============.                               
                         ..:=============...........:=============......                            
                         ....====================================.......                            
         ..........         ...================================....====....      ..........         
         -+++++++..         ......==========================.....========..      ..+++++++=         
         :+++++++..               ...====================...   ..==========...   ..+++++++:         
         .++++++++....            .........:-====-:....  ..   .....==========. ...=+++++++.         
         .++++++++....                      ......                ...========.....++++++++         
         ..++++++++...                                              ...====......++++++++         
         ..-++++++++:.                                               ...-......:++++++++-         
         ...=+++++++++.... .                                               ...+++++++++=         
         ....:++++++++++=...                                             ..=++++++++++-         
            ...++++++++++++++=:....                              ....:=++++++++++++++            
              ...++++++++++++++++=                                -++++++++++++++++            
                ...++++++++++++++=                                -++++++++++++++                
                  ....+++++++++++=                                -+++++++++++                   
                  .........=+++++=.                               -+++++=                  
"""

output = Path(output_dir) / "image_results.txt"

options = [
    "Social media - search for the image on social media",
    "Web engine - search for the image on a web engine",
    "site search - search for the image on a specific site",
]
image_extensions = ["arw", "avif", "bmp", "cr2", "dng", "eps", "exif", "gif", "heif", "ico", "indd", "jfif", "jpeg", "nef", "orf", "pam", "pbm", "pcx", "pdf", "pgm", "png", "ppm", "psd", "raw", "sgi", "sr2", "svg", "tga", "tiff", "webp", "xbm", "xcf"]


if __name__ == "__main__":
    lbl(shader(logo), 0.0625)
    
    image_dir = Path(input_dir) / "Image"
            
    out("info", "Enter the way you want to search")
    print()
    option = rich_options(options)
    print()
    
    if len(listdir(image_dir)) == 0:
        out("warning", "There is no image in Input/Image")
        exit()
        
    elif len(listdir(image_dir)) == 1:
        image = listdir(image_dir)[0]

        ext = Path(image).suffix.lower().lstrip(".")

        if ext in image_extensions:
            out("info", f"Using {image}")
        else:
            out("error", f"Not using {image} due to it not having a valid image extention")
            exit()
        
    elif len(listdir(image_dir)) > 1:
        out("info", "There is multiple files in Input/Image, choose the file you wanna use")
            
        files = listdir(image_dir)
        image = rich_options(files)
        
        ext = Path(image).suffix.lower().lstrip(".")

        if ext in image_extensions:
            out("info", f"Using {image}")
        else:
            out("error", f"Not using {image} due to it not having a image extention")
            exit()
    else:
        out("error", "Unknown error occured")
    
    if option == "Social media":
        pass
    elif option == "Web engine":
        pass
    elif option == "site search":
        pass
    